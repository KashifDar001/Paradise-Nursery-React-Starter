import { useDispatch, useSelector } from "react-redux";
import { products } from "../data/products.js";
import { addItem } from "../redux/CartSlice.jsx";

export default function ProductList() {
  const dispatch = useDispatch();
  const cartItems = useSelector((state) => state.cart.items);

  // TODO: Group products by category if required by the grading criteria.
  // TODO: Disable/replace Add to Cart after a product has been added, if required.
  return (
    <section className="page">
      <h1>Our Plants</h1>
      <p className="muted">Choose a plant to begin your indoor garden.</p>
      <div className="product-grid">
        {products.map((product) => {
          const inCart = cartItems.some((item) => item.id === product.id);
          return (
            <article className="product-card" key={product.id}>
              <img src={product.image} alt={product.name} />
              <h3>{product.name}</h3>
              <p className="muted">{product.description}</p>
              <div className="card-bottom">
                <strong>${product.price.toFixed(2)}</strong>
                <button className="button" onClick={() => dispatch(addItem(product))} disabled={inCart}>
                  {inCart ? "Added" : "Add to Cart"}
                </button>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}