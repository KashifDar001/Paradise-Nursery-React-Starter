import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { removeItem, updateQuantity } from "../redux/CartSlice.jsx";

export default function CartItem() {
  const items = useSelector((state) => state.cart.items);
  const dispatch = useDispatch();
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  // TODO: Verify the exact cart page requirements in your rubric (count, totals, and controls).
  return (
    <section className="page">
      <h1>Shopping Cart</h1>
      {items.length === 0 ? (
        <>
          <p>Your cart is empty.</p>
          <Link className="primary-button" to="/plants">Continue Shopping</Link>
        </>
      ) : (
        <>
          {items.map((item) => (
            <article className="cart-row" key={item.id}>
              <div>
                <h3>{item.name}</h3>
                <p className="muted">${item.price.toFixed(2)} each</p>
                <button className="button" onClick={() => dispatch(removeItem(item.id))}>Remove</button>
              </div>
              <div className="quantity-controls" aria-label={`Quantity for ${item.name}`}>
                <button onClick={() => dispatch(updateQuantity({ id: item.id, quantity: item.quantity - 1 }))} disabled={item.quantity <= 1}>−</button>
                <span>{item.quantity}</span>
                <button onClick={() => dispatch(updateQuantity({ id: item.id, quantity: item.quantity + 1 }))}>+</button>
              </div>
              <strong>${(item.price * item.quantity).toFixed(2)}</strong>
            </article>
          ))}
          <h2>Total: ${total.toFixed(2)}</h2>
          <Link className="primary-button" to="/plants">Continue Shopping</Link>
          {/* TODO: Add a checkout interaction only if required by your rubric. */}
        </>
      )}
    </section>
  );
}