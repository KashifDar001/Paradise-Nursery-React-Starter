export default function AboutUs() {
  return (
    <section className="page">
      <h1>About Paradise Nursery</h1>
      {/* TODO: Write an original company description that satisfies the course rubric. */}
      <p>We help plant lovers bring a little more green into everyday spaces.</p>
      <p className="muted">Add your company mission, plant-care approach, and customer promise here.</p>
    </section>
  );
}