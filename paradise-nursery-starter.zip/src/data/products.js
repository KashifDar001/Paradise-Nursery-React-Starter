// Starter data. Replace/add products and image sources to match your own project.
export const products = [
  { id: "p1", name: "Snake Plant", category: "Low Maintenance", price: 18, image: "https://images.unsplash.com/photo-1593482892290-f54927ae2b7b?auto=format&fit=crop&w=800&q=80", description: "A resilient architectural houseplant." },
  { id: "p2", name: "Monstera", category: "Tropical", price: 28, image: "https://images.unsplash.com/photo-1614594975525-e45190c55d0b?auto=format&fit=crop&w=800&q=80", description: "A statement plant with split leaves." },
  { id: "p3", name: "Peace Lily", category: "Flowering", price: 22, image: "https://images.unsplash.com/photo-1593691509543-c55fb32e5cee?auto=format&fit=crop&w=800&q=80", description: "Elegant foliage with bright blooms." },
  { id: "p4", name: "Golden Pothos", category: "Trailing", price: 15, image: "https://images.unsplash.com/photo-1616690241563-2a4f2a1d6b25?auto=format&fit=crop&w=800&q=80", description: "A versatile trailing plant." },
  { id: "p5", name: "Rubber Plant", category: "Indoor Trees", price: 32, image: "https://images.unsplash.com/photo-1509423350716-97f9360b4e09?auto=format&fit=crop&w=800&q=80", description: "Glossy leaves for a bold look." },
  { id: "p6", name: "Aloe Vera", category: "Succulents", price: 12, image: "https://images.unsplash.com/photo-1509423350716-97f9360b4e09?auto=format&fit=crop&w=800&q=80", description: "A sun-loving succulent." }
];