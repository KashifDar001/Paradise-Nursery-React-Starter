import { createSlice } from "@reduxjs/toolkit";

const initialState = { items: [] };

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addItem(state, action) {
      // TODO: Decide and implement the required duplicate-item behavior.
      const product = action.payload;
      const existing = state.items.find((item) => item.id === product.id);
      if (existing) existing.quantity += 1;
      else state.items.push({ ...product, quantity: 1 });
    },
    removeItem(state, action) {
      // TODO: Confirm whether the rubric expects an ID or object payload.
      state.items = state.items.filter((item) => item.id !== action.payload);
    },
    updateQuantity(state, action) {
      // Payload shape used by this starter: { id, quantity }.
      const { id, quantity } = action.payload;
      const item = state.items.find((entry) => entry.id === id);
      if (item && quantity > 0) item.quantity = quantity;
      // TODO: Confirm whether quantity 0 should remove the item per your rubric.
    }
  }
});

export const { addItem, removeItem, updateQuantity } = cartSlice.actions;
export default cartSlice.reducer;