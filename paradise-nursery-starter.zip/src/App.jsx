import { Link, Route, Routes } from "react-router-dom";
import AboutUs from "./components/AboutUs.jsx";
import ProductList from "./components/ProductList.jsx";
import CartItem from "./components/CartItem.jsx";

export default function App() {
  return (
    <div className="app-shell">
      <header className="site-header">
        <Link className="brand" to="/">Paradise Nursery</Link>
        <nav aria-label="Main navigation">
          <Link to="/plants">Plants</Link>
          <Link to="/about">About Us</Link>
          <Link to="/cart">Cart</Link>
        </nav>
      </header>

      <main>
        <Routes>
          <Route path="/" element={
            <section className="hero">
              <div className="hero-panel">
                <p className="eyebrow">Bring nature home</p>
                <h1>Paradise Nursery</h1>
                <p>Discover plants that make your space feel alive.</p>
                {/* TODO: confirm the CTA label and route match your rubric. */}
                <Link className="primary-button" to="/plants">Get Started</Link>
              </div>
            </section>
          } />
          <Route path="/about" element={<AboutUs />} />
          <Route path="/plants" element={<ProductList />} />
          <Route path="/cart" element={<CartItem />} />
          <Route path="*" element={<section className="page"><h1>Page not found</h1><Link to="/">Return home</Link></section>} />
        </Routes>
      </main>
      <footer className="site-footer">Paradise Nursery · Grow something wonderful.</footer>
    </div>
  );
}