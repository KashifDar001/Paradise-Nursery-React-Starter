# Paradise Nursery — React Starter

A starter structure for the Paradise Nursery plant-shop assignment. Complete the TODOs yourself, run the app, and test each required behavior before submitting.

## Requirements checklist
- [ ] Landing page with company name and Get Started button
- [ ] About Us page/component describing the company
- [ ] Background image styling in `src/App.css`
- [ ] Product listing with categories, product cards, and add-to-cart actions
- [ ] Redux cart slice with `addItem`, `removeItem`, and `updateQuantity`
- [ ] Shopping cart with quantity controls, item removal, totals, and continue-shopping navigation
- [ ] README project details and screenshots (optional but useful)

## Run locally
1. Install Node.js (LTS).
2. Extract this folder and open a terminal in it.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL printed by Vite.
6. Run `npm run build` to check for build errors.

## GitHub URLs for your submission
After pushing this repository publicly, use the file's GitHub page URL, not a raw-file URL. Example format:
`https://github.com/YOUR-USERNAME/YOUR-REPOSITORY/blob/main/README.md`

Replace the filename at the end for each requested file:
- `README.md`
- `src/components/AboutUs.jsx`
- `src/App.css`
- `src/App.jsx`
- `src/redux/CartSlice.jsx`
- `src/components/ProductList.jsx`
- `src/components/CartItem.jsx`

Your actual username and repository name must replace the placeholders. Verify each link in a signed-out/private browser window before submitting.

## Important
This is a learning scaffold, not a finished submission. Implement and test the TODOs against your course rubric; do not submit unfinished starter files.
